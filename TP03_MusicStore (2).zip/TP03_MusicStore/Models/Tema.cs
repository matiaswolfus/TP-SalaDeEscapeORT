namespace TP03_MusicStore.Models;

public class Tema
{
    public string nombre;

    public Tema(string nombre)
    {
        this.nombre = nombre;
    }
}
