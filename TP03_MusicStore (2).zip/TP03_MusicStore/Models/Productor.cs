namespace TP03_MusicStore.Models;

public class Productor
{
    public string nombre;

    public Productor(string nombre)
    {
        this.nombre = nombre;
    }
}
