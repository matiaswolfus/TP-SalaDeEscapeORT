namespace TP03_MusicStore.Models;

public class Artista
{
    public string nombre;

    public Artista(string nombre)
    {
        this.nombre = nombre;
    }
}
