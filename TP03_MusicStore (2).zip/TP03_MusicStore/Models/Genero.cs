namespace TP03_MusicStore.Models;

public class Genero
{
    public string nombre;

    public Genero(string nombre)
    {
        this.nombre = nombre;
    }
}
