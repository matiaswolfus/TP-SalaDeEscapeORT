﻿using System;
using System.Collections.Generic;
using System.Net;

namespace TP0
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int opcion = 0;
            Torneo torneoN = new Torneo();
            do
            {
                mostrarMenu();
                opcion = seleccionarOp();
                seguir();
                switch (opcion)
                {
                    case 1:
                        agregarRobot(torneoN);
                        tocarTecla();
                        break;
                    case 2:
                        agregarPuntuacion(torneoN);
                        break;
                    case 3:
                        string nombre;
                        List<int> puntuaciones = new List<int>();
                        nombre = ingresarString("ingrese el nombre del robot al cual quiere agregar una puntuacion");
                        torneoN.mostrarResultados(nombre);
                        tocarTecla();
                        break;
                    case 4:
                        torneoN.mejorRobot();
                        tocarTecla();
                        break;
                    case 5:
                        torneoN.listarRobots();
                        tocarTecla();
                        break;
                
                }

            } while (opcion != 6);

        }

        private static void agregarPuntuacion(Torneo torneoN)
        {
            int puntuacion;
            string nombre;

            nombre = ingresarString("ingrese el nombre del robot al cual quiere agregar una puntuacion");
            puntuacion = puntuacionValida();
            torneoN.cargarPuntuacion(nombre, puntuacion);
            tocarTecla();
        }

        private static void agregarRobot(Torneo torneoN)
        {
            bool sePuede = false;

            sePuede = torneoN.agregarRobot(ingresarString("ingrese el nombre del robot nuevo"));
            if (sePuede == false)
            {
                Console.WriteLine("robot ya existente");
            }
            else
            {
                Console.WriteLine("robot agregado correctamente");
            }
        }

        private static void mostrarMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("INGRESE LA OPCION QUE DESEA HACER: ");
            Console.WriteLine("1.Agregar un nuevo robot: ");
            Console.WriteLine("2. Agregar puntuación a un robot: ");
            Console.WriteLine("3. Mostrar los resultados de un robot: ");
            Console.WriteLine("4. Mostrar el robot con el mejor promedio: ");
            Console.WriteLine("5. Listar todos los robots: ");
            Console.WriteLine("6. Salir: ");
        }
        static int seleccionarOp()
        {
            int opcion;
            do
            {
                opcion = ingresarInt("ingrese el numero de opcion que desea:");
                if (!(opcion >= 1 && opcion <= 6))
                {
                    Console.WriteLine("ERROR, REINGRESAR");
                }
            }
            while (!(opcion >= 1 && opcion <= 6));
            return opcion;
        }
        static int puntuacionValida()
        {
            int opcion;
            do
            {
                opcion = ingresarInt("ingrese el numero de opcion que desea (1-10):");
                if (!(opcion >= 1 && opcion <= 10))
                {
                    Console.WriteLine("ERROR, REINGRESAR");
                }
            }
            while (!(opcion >= 1 && opcion <= 6));
            return opcion;
        }
        static int ingresarInt(string msj)
        {
            int aux;
            Console.WriteLine(msj);
            aux = int.Parse(Console.ReadLine());
            return aux;
        }
        static void seguir()
        {
            System.Threading.Thread.Sleep(1000);
            Console.Clear();
        }
        static string ingresarString(string msj)
        {
            string aux;
            Console.WriteLine(msj);
            aux = Console.ReadLine();
            return aux;
        }
        static void tocarTecla()
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("ingrese cualquier cosa para seguir");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.ReadKey();
            Console.Clear();
        }
    }
}
